<?php
    require('../core/config.php');
    require('../core/system.php');

    /* $movies = $db->query('SELECT * FROM `movies`');
    $movies_arr = [];
    while( $movie = $movies->fetch_object())
    {
        $movies_arr[]= $movie;
        
    }
    echo "<pre>";
    echo $movies->num_rows;
    echo '<br>';
    echo count($movies_arr); */
     $folder_path = '../uploads/actors/*';
     $actors_folder=glob($folder_path); //scandir($folder_path); //  
     foreach ($actors_folder as $single_file) {
         if(is_file($single_file))
         {
             unlink($single_file);
         }
     }
    $imdbid = 'tt0332280';
    $movieOutput = run_tmdb_curl($imdbid)->movie_results[0];
    $db_movie = $db->query('SELECT * FROM `movies` WHERE `imdbid`="'.$imdbid.'" LIMIT 1');
    $result = $db_movie->fetch_object();
    $movie_id = $result->id;
    /* echo "<pre>";
    print_r($result);
    exit; */
    if (!empty($movieOutput)) {
        $video_name = $movieOutput->video;
        if ($video_name != "") {
            $new_file_name = md5(mt_rand()) . '_video.mp4';
            $url = $video_name;
            $img = '../uploads/masonry_images/' . $new_file_name;
            file_put_contents($img, file_get_contents($url));
        }
        /*Geners Start*/

        /*Actors Starts*/
        $actors_url = "https://api.themoviedb.org/3/movie/{$imdbid}/credits?api_key=".TMDB_KEY."&external_source=imdb_id";
        $json = runCurl($actors_url);
        $array1 = get_object_vars($json);
      
        $imgs = [];
        foreach ($array1['cast'] as $cast) {
           
            $name_c = $cast->name;
            $nconst = $cast->id;
            $name_c = $cast->name;
            $nconst = $cast->id;
            $json = runCurl("https://api.themoviedb.org/3/person/{$nconst}?api_key=".TMDB_KEY."&language=en-US");
            $array = get_object_vars($json);
            $aname = $array['name'];
            $birthday = $array['birthday'];
            $place_of_birth = $array['place_of_birth'];
            $biography = addslashes($array['biography']);
            $imdb_id = $array['imdb_id'];
            $actor_img = $array['profile_path'];
            $im_url_c = "https://image.tmdb.org/t/p/original" . $actor_img;
            if ($actor_img != '') {
                $extension = strtolower(explode('.', $actor_img)[1]);
                $c_actor = generate_postname($aname) . '_actor' . time() . '.' . $extension;
                $imgs[] = $c_actor. '-'. $im_url_c;
                $ur11 = $im_url_c;
                resize(file_get_contents($im_url_c), $c_actor, UPLOAD_PATH . 'actors/', 50);
                $img = UPLOAD_PATH . 'actors/' . $c_actor;
            } else {
                $c_actor = "";
            }

            $sql1 = "SELECT * FROM actors WHERE actor_name LIKE '%" . $aname . "%'";
            $result1 = $db->query($sql1);
            if ($result1->num_rows <= 0) {
                $db->query("INSERT INTO actors (actor_name,actor_picture,actor_nconst,birthday,place_of_birth,biography,actor_img_url,imdbid) VALUES ('" . $aname . "','" . $c_actor . "','" . $nconst . "','" . $birthday . "','" . $place_of_birth . "','" . $biography . "','" . $im_url_c . "','" . $imdb_id . "')");
                $actor_id = $db->insert_id;
            } 
            else 
            {
                while ($row1 = $result1->fetch_assoc()) {
                    $actor_id = $row1['id'];
                    $a = "UPDATE actors SET actor_name = '$aname',actor_picture ='$c_actor',actor_nconst = '$nconst',birthday='$birthday', place_of_birth='$place_of_birth',biography='$biography',actor_img_url='$im_url_c',imdbid='$imdb_id' WHERE id = '$actor_id'";
                    $db->query($a);
                }
            }
            $make_actors[] = $actor_id;
        }
    

       /*  echo "<pre>";
        echo $im_url_c;
        echo '<br>';
        print_r($c_actor);
        exit; */

        

         $makeactors = implode(",", $make_actors);
         $actors = explode(',', $makeactors);
            // Actors Ends
            $db->query('DELETE FROM `actor_relations` WHERE `movie_id`={$movie_id}');
            if(!empty($actors)){
                foreach ($actors as $actor => $actor_id) {
                    $db->query("INSERT INTO actor_relations(movie_id,actor_id) VALUES ('{$movie_id}','{$actor_id}')");
                }
            }
            $movie_id = $db->insert_id;
            $db->query("UPDATE movies SET all_starcast = 'yes' WHERE id = '{$movie_id}'");
    }

    
     

?>