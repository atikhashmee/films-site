<?php
include "core/config.php";
include "core/system.php";
echo $_GET['id'];
?>