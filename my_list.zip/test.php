<?Php

echo ini_get('max_execution_time');

?>