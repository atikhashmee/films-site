<?php
session_set_cookie_params(172800);
session_start();
require('../core/config.php');
require('../core/system.php');
$admin = new Data($db,$domain);
$admin->startUserSession($_SESSION);
$admin->verifySession(true);
$admin->verifyAdmin(true);

$id = $_GET['id'];

$db->query("DELETE FROM actors WHERE id='".$id."'");
$db->query("DELETE FROM actor_relations WHERE actor_id='".$id."'");
header('Location: actors.php');
exit;