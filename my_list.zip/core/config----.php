<?php
    $domain = 'http://localhost/imdb';

    // Database Configuration
    $_db['host'] = '';
    $_db['user'] = 'root';
    $_db['pass'] = 'root';
    $_db['name'] = 'imdb';

    $db = new mysqli($_db['host'], $_db['user'], $_db['pass'], $_db['name']) or die('MySQL Error');

    error_reporting(0);
    