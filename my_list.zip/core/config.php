<?php
    $domain = 'http://film.localhost.com';
define("TMDB_KEY","bc457c6e89c45bbb2f34a7bdd23688cf");
    // Database Configuration
    $_db['host'] = 'localhost';
    $_db['user'] = 'root';
    $_db['pass'] = '';
    $_db['name'] = 'film_imdb';

    $db = new mysqli($_db['host'], $_db['user'], $_db['pass'], $_db['name']) or die('MySQL Error');

    //error_reporting(0);
    